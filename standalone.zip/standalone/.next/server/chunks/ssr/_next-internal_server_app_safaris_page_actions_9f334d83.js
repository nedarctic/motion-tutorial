module.exports=[16697,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_safaris_page_actions_9f334d83.js.map