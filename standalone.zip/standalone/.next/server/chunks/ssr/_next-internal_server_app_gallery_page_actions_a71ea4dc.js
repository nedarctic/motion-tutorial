module.exports=[11797,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gallery_page_actions_a71ea4dc.js.map