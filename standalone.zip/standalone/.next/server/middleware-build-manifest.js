globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9b151ba2d25663e1.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/7169130a7c6aeab7.js",
    "static/chunks/cc8072acd6c4335d.js",
    "static/chunks/7dc285941dc7880a.js",
    "static/chunks/turbopack-71eac8744f1119ee.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];